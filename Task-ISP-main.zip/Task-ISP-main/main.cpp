#include "TaskISP.h"

int main() {
    mainMenu();
    return 0;
}
